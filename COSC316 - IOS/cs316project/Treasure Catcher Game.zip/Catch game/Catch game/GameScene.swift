//
//  GameScene.swift
//  Catch game
//
//  Created by COSC Student on 2025-04-09.
//

import SpriteKit
import GameplayKit

enum GameState {
    case Menu
    case Playing
    case Score
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var score = 0
    var lives = 5
    var scoreLabel: SKLabelNode!
    var livesLabel: SKLabelNode!
    
    var container: SKSpriteNode!
    
    var background: SKSpriteNode!
    
    var titleBox: SKSpriteNode!
    var titleLabel: SKLabelNode!
    
    var playButton: SKSpriteNode!
    
    var state: GameState! = GameState.Menu
    
    var fallSpeed: CGFloat = -50
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        // print("Scene loaded")
        initMenu()
        
    }
    
    func spawnFallingObject() {
        // randomly select an item to  spawn
        let itemImages = ["coin1", "coin2", "coin3", "gem1", "gem2"]
        let isBomb = Int.random(in: 1...100) <= 30 // 30% chance to spawn bomb
        
        // choose texture
        let objectTexture: SKTexture
        if isBomb{
            objectTexture = SKTexture(imageNamed: "bomb")
        } else {
            objectTexture = SKTexture(imageNamed: itemImages.randomElement()!)
        }
        
        // filtering mode nearest can apparently help with blur on scaling up textures
        objectTexture.filteringMode = .nearest
        
        //create sporite with chosen texture
        let object = SKSpriteNode(texture: objectTexture)
        
        let objectSize = size.width * 0.1
        object.size = CGSize(width: objectSize, height: objectSize)
        
        // spawn at a random x pos
        let spawnX = CGFloat.random(in: objectSize...(size.width - objectSize))
        object.position = CGPoint(x: spawnX, y: size.height + objectSize / 2)
        object.zPosition = 2
        
        // object physics
        // basic physics so that the item can fall
        // and be detected by container
        object.physicsBody = SKPhysicsBody(circleOfRadius: objectSize / 2)
        object.physicsBody?.affectedByGravity = true
        object.physicsBody?.linearDamping = 0 // make fall speed constant
        // OLD object.physicsBody?.velocity = CGVector(dx: 0, dy: -150) // dy controls fall speed
        // NEW: scaling fall speed
        object.physicsBody?.velocity = CGVector(dx: 0, dy: fallSpeed)
        fallSpeed = max(fallSpeed - 5, -500)
        object.physicsBody?.categoryBitMask = 0x1 << 1
        object.physicsBody?.contactTestBitMask = 0x1 << 0
        object.physicsBody?.collisionBitMask = 0
        
        addChild(object)
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if contactMask == (0x1 << 0 | 0x1 << 1){
            if let nodeA = contact.bodyA.node, let nodeB = contact.bodyB.node {
                // remove the object that is not the container
                if nodeA == container{
                    nodeB.removeFromParent()
                    print("object removed")
                }else{
                    nodeA.removeFromParent()
                    print("object removed")
                }
                // scoring logic
                // coin1: 1, coin2: 1, coin3: 2, gem1: 5, gem2: 3
                // check which node was caught
                let caughtNode = nodeA == container ? nodeB : nodeA
                if let textureName = (caughtNode as? SKSpriteNode)?.texture?.description {
                    if textureName.contains("coin1") || textureName.contains("coin2") {
                        score += 1
                        flashBucket(color: .green)
                    } else if textureName.contains("coin3") {
                        score += 2
                        flashBucket(color: .green)
                    } else if textureName.contains("gem1") {
                        score += 5
                        flashBucket(color: .yellow)
                    } else if textureName.contains("gem2") {
                        score += 3
                        flashBucket(color: .yellow)
                    } else if textureName.contains("bomb") {
                        lives -= 1
                        flashBucket(color: .red)
                        if lives <= 0 {
                            showScore()
                            return
                        }
                    }
                    scoreLabel.text = "Score: \(score)"
                    livesLabel.text = "Lives: \(lives)"
                }
            }
        }
    }
    
    func flashBucket(color: UIColor) {
        // function (attempting) to make the bucket glow when you catch something
        // init the glowing effect
        let glow = SKShapeNode(circleOfRadius: container.size.width / 2 + 10)
        glow.position = container.position
        glow.fillColor = .clear
        glow.strokeColor = color
        glow.lineWidth = 6
        glow.zPosition = 3
        glow.alpha = 0.75
        addChild(glow)
        
        // fade out the glowing effect
        let fadeOut = SKAction.fadeOut(withDuration: 0.3)
        let remove = SKAction.removeFromParent()
        glow.run(SKAction.sequence([fadeOut, remove]))
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    func initMenu() {
        
        state = GameState.Menu
        
        // init background
        background = SKSpriteNode(imageNamed: "background")
        background.size = CGSize(width: size.height, height: size.height)
        background.zPosition = 1
        background.position = CGPoint(x: size.width / 2, y: size.height / 2)
        addChild(background)
        
        // init title
        // title box image dimension: 85x160
        titleBox = SKSpriteNode(imageNamed: "titleBox")
        titleBox.zPosition = 2
        titleBox.size = CGSize(width: size.width * 0.75, height: (size.width * 0.75) * (85 / 160))
        titleBox.position = CGPoint(x: size.width / 2, y: size.height * 0.65)
        addChild(titleBox)
        
        titleLabel = SKLabelNode(fontNamed: "Helvetica Bold")
        titleLabel.zPosition = 3
        titleLabel.fontSize = size.width * 0.085 // set to a % of screens width
        titleLabel.text = "Treasure Bucket!"
        titleLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.65)
        addChild(titleLabel)
        
        // init play button
        playButton = SKSpriteNode(imageNamed: "playButton")
        playButton.name = "playButton"
        playButton.zPosition = 3
        playButton.size = CGSize(width: size.width * 0.75, height: (size.width * 0.75) * (85 / 160))
        playButton.position = CGPoint(x: size.width / 2, y: size.height * 0.45)
        addChild(playButton)
    }
    
    func removeMenu(){
        titleBox.removeFromParent()
        titleLabel.removeFromParent()
        playButton.removeFromParent()
    }
    
    func initGame(){
        
        score = 0
        lives = 5
        
        // init background - was disapearing when pressing retry button this is a bandaid fix
        background = SKSpriteNode(imageNamed: "background")
        background.size = CGSize(width: size.height, height: size.height)
        background.zPosition = 1
        background.position = CGPoint(x: size.width / 2, y: size.height / 2)
        addChild(background)
        
        // init score label
        scoreLabel = SKLabelNode(fontNamed: "Helvetica")
        scoreLabel.fontSize = size.width * 0.08
        scoreLabel.fontColor = .black
        scoreLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.90)
        scoreLabel.zPosition = 10
        scoreLabel.text = "Score: 0"
        addChild(scoreLabel)
        
        // init lives label
        livesLabel = SKLabelNode(fontNamed: "Helvetica")
        livesLabel.fontSize = size.width * 0.06
        livesLabel.fontColor = .black
        livesLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.85)
        livesLabel.zPosition = 10
        livesLabel.text = "Lives: 3"
        addChild(livesLabel)
        
        // set state
        state = GameState.Playing
        
        // init the player
        container = SKSpriteNode(imageNamed: "bucket")
        container.size = CGSize(width: size.width * 0.25, height: size.width * 0.1)
        container.position = CGPoint(x: size.width / 2, y: container.size.height / 2 + 20)
        container.zPosition = 2
        
        
        // player physics body (for collisions)
        container.physicsBody = SKPhysicsBody(rectangleOf: container.size)
        container.physicsBody?.isDynamic = false
        container.physicsBody?.categoryBitMask = 0x1 << 0 // add object to category 1
        container.physicsBody?.contactTestBitMask = 0x1 << 1 // set type of object (category 2) that container gets notified about touching
        container.physicsBody?.collisionBitMask = 0 // makes it so it doesnt physically bump into things
        
        
        addChild(container)
        
        // start spawning objects
        // doing this by creating a runnable action that calls spawnFallingObjects
        // make it a weak action for memory cleanup
        let spawnAction = SKAction.run{ [weak self] in
            self?.spawnFallingObject()
        }
        let waitAction = SKAction.wait(forDuration: 0.75)
        let spawnSequence = SKAction.sequence([spawnAction, waitAction])
        run(SKAction.repeatForever(spawnSequence), withKey: "spawnObjects")
    }
    
    func showScore(){
        state = GameState.Score
        
        // stop spawning items
        removeAction(forKey: "spawnObjects")
        
        // remove remaining game elements
        container.removeFromParent()
        scoreLabel.removeFromParent()
        livesLabel.removeFromParent()
        
        // show game over label
        let gameOverLabel = SKLabelNode(fontNamed: "Helvetica-Bold")
        gameOverLabel.text = "YOU EXPLODED!"
        gameOverLabel.fontSize = size.width * 0.1
        gameOverLabel.fontColor = .red
        gameOverLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.65)
        gameOverLabel.zPosition = 10
        gameOverLabel.name = "gameOverLabel"
        addChild(gameOverLabel)
        
        // final score label
        let finalScore = SKLabelNode(fontNamed: "Helvetica")
        finalScore.text = "final score: \(score)"
        finalScore.fontSize = size.width * 0.05
        finalScore.fontColor = .red
        finalScore.position = CGPoint(x: size.width / 2, y: size.height * 0.58)
        finalScore.zPosition = 10
        finalScore.name = "finalScoreLabel"
        addChild(finalScore)
        
        // retry button
        let retryButton = SKSpriteNode(imageNamed: "retryButton")
        retryButton.name = "retryButton"
        retryButton.size = CGSize(width: size.width * 0.1, height: size.width * 0.12)
        retryButton.position = CGPoint(x: size.width / 2, y: size.height * 0.4)
        retryButton.zPosition = 10
        addChild(retryButton)
        
        // menu button
        let menuButton = SKSpriteNode(imageNamed: "menuButton")
        menuButton.name = "menuButton"
        menuButton.size = CGSize(width: size.width * 0.1, height: size.width * 0.12)
        menuButton.position = CGPoint(x: size.width / 2, y: size.height * 0.30)
        menuButton.zPosition = 10
        addChild(menuButton)
        
    }
    
    func removeScore(){
        removeAllChildren()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return } // safely unwrap touches set
        let location = touch.location(in: self)
        let touchedNode = atPoint(location)
        
        if state == GameState.Menu {
            if touchedNode.name == "playButton" {
                removeMenu()
                initGame()
            }
        } else if state == GameState.Playing {
            // move container to where player touched (only horizontally)
            let moveAction = SKAction.moveTo(x: location.x, duration: 0.2)
            container.run(moveAction)
        } else if state == GameState.Score{
            if touchedNode.name == "retryButton"{
                removeScore()
                initGame()
            } else if state == GameState.Score {
                removeScore()
                initMenu()
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        // function so that player can move bucket by dragging finger aswell
        guard let touch = touches.first else { return }
        if state == GameState.Playing {
            let location = touch.location(in: self)
            container.position.x = location.x
        }
    }
}
