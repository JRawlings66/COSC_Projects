//
//  ViewController.swift
//  MyTabBarApp_Lab7
//
//  Created by COSC Student on 2025-03-16.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

