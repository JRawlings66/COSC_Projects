//
//  WebViewController.swift
//  MyTabBarApp_Lab7
//
//  Created by COSC Student on 2025-03-16.
//
// NOTE: website credentials:
// username: admin
// password: letmein

import UIKit
import WebKit

class WebViewController: UIViewController{
    @IBOutlet weak var webView: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadWebsite()
    }
    
    override func viewDidAppear(_ animated: Bool){
        super.viewDidAppear(animated)
        print("WebViewCOntroller loaded successfully")
    }
    
    func loadWebsite(){
        let urlString = "http://10.12.80.111"
        if let url = URL(string: urlString){
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
}
